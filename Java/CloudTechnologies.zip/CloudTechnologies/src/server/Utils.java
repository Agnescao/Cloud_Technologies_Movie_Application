package server;

import java.sql.Connection;
import java.sql.DriverManager;

class Utils {
	
	static Connection connection = null;
   public static Connection getConnection() {
	   
	   if(connection != null){
		   return connection;
	   }
      
      try {
         Class.forName("org.apache.hadoop.hive.jdbc.HiveDriver");
         connection = DriverManager.getConnection(
        		 "jdbc:hive://localhost:10000/movielens", "", "");
      } catch (Exception e) {
         e.printStackTrace();
      }
      return connection;
   }

}
