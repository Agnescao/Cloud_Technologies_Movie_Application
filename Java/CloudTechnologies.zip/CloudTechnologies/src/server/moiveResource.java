package server;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/movie")
public class moiveResource {
	
//	@GET
//	  @Produces({  MediaType.APPLICATION_JSON,
//	      MediaType.TEXT_XML })
//	  public List<Movie> getPopularMovies() {
//	    return MovieDao1.instance.getPopularMovies();
//	  }
//	
//	@GET
//	  @Produces({  MediaType.APPLICATION_JSON,
//	      MediaType.TEXT_XML })
//	  public List<Movie> getTop10MoviesRating() {
//	    return MovieDao1.instance.getTop10MoviesRating();
//	  }
	@GET
	  @Produces({  MediaType.APPLICATION_JSON,
	      MediaType.TEXT_XML })
	  public List<Movie> getTop10MoviesGeners() {
	    return MovieDao1.instance.getTop10MoviesGeners();
	  }



}
