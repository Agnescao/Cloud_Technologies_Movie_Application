package server;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
@XmlRootElement(name = "movie")
@XmlType(propOrder = { "m_title", "rating", "m_genres", "u_gener", "u_age", "u_occupation" })
public class Movie {
	
	private String m_title;
	private int rating;
	private String m_genres;
	private String u_gener;
	private int u_age;
	private String u_occupation;
	
	
	
	public Movie(String m_title, int rating, String m_genres, String u_gener, int u_age, String u_occupation) {
		super();
		this.m_title = m_title;
		this.rating = rating;
		this.m_genres = m_genres;
		this.u_gener = u_gener;
		this.u_age = u_age;
		this.u_occupation = u_occupation;
	}
	public Movie(String m_title, int rating) {
		// TODO Auto-generated constructor stub
		this.m_title = m_title;
		this.rating = rating;
		
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getM_genres() {
		return m_genres;
	}
	public void setM_genres(String m_genres) {
		this.m_genres = m_genres;
	}
	public String getU_gener() {
		return u_gener;
	}
	public void setU_gener(String u_gener) {
		this.u_gener = u_gener;
	}
	public int getU_age() {
		return u_age;
	}
	public void setU_age(int u_age) {
		this.u_age = u_age;
	}
	public String getU_occupation() {
		return u_occupation;
	}
	public void setU_occupation(String u_occupation) {
		this.u_occupation = u_occupation;
	}
	
	
	

}
