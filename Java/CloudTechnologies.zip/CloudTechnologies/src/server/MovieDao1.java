package server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public enum MovieDao1 {
	instance;
	
	
	public List<Movie> getTop10MoviesGeners() { 
		List<Movie> movies = new ArrayList<Movie>();
		
		String sqlSelect = "select m_title, sum(rating) rating "
				+ "from movielens.rating_full "
				+ "where u_gender = 'M' group "
				+ "by m_titlse order "
				+ "by rating desc limit 10;";
		
		Connection connection = Utils.getConnection();

		try {
			PreparedStatement psmt = connection.prepareStatement(sqlSelect);

			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				Movie b = new Movie(
						
						rs.getString("m_title"), 
						rs.getInt("rating")
						/*rs.getString("m_genres"), 
						rs.getString("u_gener"),
						rs.getInt("u_age"), 
						rs.getString("u_occupation")*/);
				movies.add(b);
			}
			System.out.println("get all movies");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return movies;
	}
	
	
}
	

